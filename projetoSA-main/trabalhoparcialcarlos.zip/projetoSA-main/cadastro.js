function validateDocumento(documento, tipoDocumento) {
    if (documento.length > 0) {
      return true; 
    } else {
      return false;
    }
  }
  
  const form = document.querySelector('form');
  
  form.addEventListener('submit', (event) => {
    event.preventDefault();
  
    const usernameInput = document.querySelector('input[placeholder="Digite usuário:"]');
    const passwordInput = document.querySelector('input[placeholder="Senha:"]');
    const documentoInput = document.querySelector('input[placeholder="CPF ou CNPJ?"]');
    const tipoDocumentoSelect = document.getElementById('tipoDocumento');
  
    const username = usernameInput.value.trim();
    const password = passwordInput.value.trim();
    const documento = documentoInput.value.trim();
    const tipoDocumento = tipoDocumentoSelect.value;
  

    let isValid = true;
  
    if (username === '') {
      isValid = false;
      alert('Por favor, preencha o campo de usuário');
    }
  
    if (password === '') {
      isValid = false;
      alert('Por favor, preencha o campo de senha');
    }
  
    if (!validateDocumento(documento, tipoDocumento)) {
      isValid = false;
      alert('Por favor, insira um CPF ou CNPJ válido');
    }
  
    if (isValid) {
      alert('Cadastro enviado com sucesso! (Simulação)');
    }
  });
  
let resposta = document.getElementById('resposta');
let submit = document.getElementById('submit');

submit.addEventListener('click',()=>{
    const situacao = document.getElementById('situacao').value
    const cpf = document.getElementById('cpf').value
    const telefone = document.getElementById('telefone').value
    const cargo = document.getElementById('cargo').value
    const nome = document.getElementById('nome').value

    const dados = {
        nomeFuncionario : nome,
        cpfFuncionario:cpf,
        telefoneFuncionario:telefone,
        cargoFuncionario:cargo,
        situacaoFuncionario:situacao

    }

    fetch('http://localhost:8080/funcionario',{
        method:"POST",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify(dados)
    })
    .then(resultado => resultado.json())
    .then(valores => {
        console.log(valores)
        resposta.innerHTML = "Código Funcionário: "+valores.codFuncionario+"<br>"
        resposta.innerHTML += "Nome Funcionário: "+valores.nomeFuncionario+"<br>"
        resposta.innerHTML += "Cargo Funcionário: "+valores.cargoFuncionario+"<br>"
        resposta.innerHTML += "CPf Funcionário: "+valores.cpfFuncionario+"<br>"
        resposta.innerHTML += "Telefone Funcionário: "+valores.telefoneFuncionario+"<br>"
        resposta.innerHTML += "Telefone Funcionário: "+valores.situacaoFuncionario+"<br>"
    })
    .catch((err)=>{
        console.error("Erro de conexão com o sistema!",err);
    })


})